/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 2.4									*
 * Tarih: 04-06-2014									*
 * A��klama: Kesme kulllan�m uygulamas�					*
 * **************************************************** */

#include <msp430.h> 

unsigned char bGecikme;						// Gecikme de�i�keni.
void main(void) {
    WDTCTL = WDTPW | WDTHOLD;				// Watchdog timeri durdur.
    P1DIR |=  BIT0;							// Port1.0 ��k��.
    P2DIR &= ~BIT0;							// Port2.0 giri�.
    P2REN |=  BIT0;							// Port2.0 direnci aktif.
    P2OUT |=  BIT0;							// Port2.0 direnci Pull-Up.
    P2IE  |=  BIT0;							// Port2.0 kesmesini a�.
    P2IES |=  BIT0;							// D��en kenar kesmesini se�.
    P2IFG |=  BIT0;							// Kesme bayra��n� temizle.
    _bis_SR_register(LPM4_bits + GIE);		// LPM4 moduna gir ve kesmeleri a�
}

// Port 2 kesme vekt�r�
#pragma vector=PORT2_VECTOR
__interrupt void Port_2(void)
{
  P1OUT ^= BIT0;                			// Port1.0'� tersle.
  while(!(P2IN & BIT0));					// Buton b�rak�lana kadar bekle.
  for(bGecikme=0;bGecikme<250;bGecikme++);	// Buton ark�n� �nlemek i�in biraz bekle.
  P2IFG &= ~BIT0;               			// Kesme bayra��n� temizle.
}
