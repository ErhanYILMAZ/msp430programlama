/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 7.3									*
 * Tarih: 04-06-2014									*
 * A��klama: UART ile s�cakl�k bilgisi aktar�m�			*
 * **************************************************** */

#include <msp430.h>								// MSP430 ba�l�k dosyas�

unsigned short wGecikmeSayac=0;					// Gecikme sayac�
unsigned long	wSicaklik;						// S�cakl�k de�erini tutan de�i�ken
unsigned char bTXSayac=0;						// Giden veri sayac�
unsigned char bYazi[15]={"SICAKLIK=xx�C\n\r"};	// G�nderilecek yaz�
void main(void)
{
  WDTCTL  = WDTPW | WDTHOLD;		// Watchdog timeri durdur.
  DCOCTL = 0;						// Dahili osilat�r ayarlar�n� en d���k yap
  BCSCTL1 = CALBC1_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla
  DCOCTL = CALDCO_1MHZ;				// Dahili osilat�r� 1MHz'e ayarla
  P1SEL =  BIT2 ;					// P1.2=TXD
  P1SEL2 = BIT2 ;					// P1.2=TXD
  UCA0CTL1 |= UCSSEL_2;				// UART Ayarlar�, Saat kayna�� SMCLK
  UCA0BR0 = 104;					// 1MHz 9600 bud ayar�
  UCA0BR1 = 0;						// 1MHz 9600 baud ayar�
  UCA0MCTL = UCBRS0;				// UART Baud hassas ayar
  UCA0CTL1 &= ~UCSWRST;				// USCI birimini haz�rla
  TA0CCTL0 = CCIE;					// Timer0 CCR0 ayarlar�
  TA0CCR0  = 5000-1;				// Timer0 kesme periyodu 5ms
  TA0CTL   = TASSEL_2 + MC_2;		// Timer0 ayarlar�
  ADC10CTL1 = INCH_10 + ADC10DIV_3; // S�cakl�k sens�r� se�ilir. ADC10CLK/4
  // ADC10 ayarlar�, dahili 1.5V referans, kesmeleri a�
  ADC10CTL0 = SREF_1 + ADC10SHT_3 + REFON + ADC10ON + ADC10IE;
  __bis_SR_register(GIE);			// Genel kesmeleri a�
  while(1){							// Sonsuz d�ng�
  __bis_SR_register(LPM0_bits);		// ��lemciyi uykuya sok
  wSicaklik = ADC10MEM;			// �evrim sonucunu kaydet
  wSicaklik = ((wSicaklik - 673) * 423) / 1024;	// �evrim sonucubu santigrat dereceye �evir
  wSicaklik %=100;				// Sonucun 0-99 aras�nda olmas�n� sa�la
  bYazi[9] = wSicaklik/10+0x30;	// S�cakl�k de�eri birler basama��(ascii)
  bYazi[10]= wSicaklik%10+0x30;	// S�cakl�k de�eri onlar basama��(ascii)
  IE2 |= UCA0TXIE;				// G�nderme kesmesini a�
  UCA0TXBUF = bYazi[0];			// G�ndermeye ba�la
  bTXSayac=1;					// G�nderme sayac�n� ayarla
 }
}
// USCIAB0TX kesme vekt�r�
#pragma vector=USCIAB0TX_VECTOR
__interrupt void USCI0TX_ISR(void)
{
  UCA0TXBUF = bYazi[bTXSayac];		// s�radaki karakteri g�nder
  if (++bTXSayac>=15){				// T�m karakterler gitti mi?
  IE2 &= ~UCA0TXIE;					// Evet ise g�nderme kesmesini kapat
  bTXSayac=0;						// G�dnerme sayasc�n� s�f�rla
  }
  }

// Timer_A0 CCR0 kesme vekt�r�
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
{
	if(++wGecikmeSayac>=600){			// 3 saniye oldu mu?
	wGecikmeSayac=0;					// Zaman sayac�n� s�f�rla
	ADC10CTL0 |= ENC + ADC10SC;         // AD �evrimi ba�lat
	}
	TA0CCR0 += 5000;					// Timeri yeniden kur.
}

// ADC10 kesme vekt�r�
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
  __bic_SR_register_on_exit(CPUOFF);	// ��lemciyi uykudan uyand�r.
}
