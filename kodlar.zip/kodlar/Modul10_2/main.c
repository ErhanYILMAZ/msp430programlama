/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 10.2									*
 * Tarih: 04-06-2014									*
 * A��klama: SD kart ile �ifreli kilit uygulamas�		*
 * **************************************************** */


#include <msp430.h>			// MSP430 ba�l�k dosyas�
// SD kart kullan�m� ile ilgili k�t�phane dosyalar�
#include <stdint.h>
#include "pff2a/src/diskio.h"
#include "pff2a/src/pff.h"
#include "drivers/spi.h"
/////////////////////////////////////////////////////
// Kullan�lan fonksiyon prototipleri
void Yanlis(void);
void Dogru (void);
void Bekle(unsigned int);
// Dosya sisteminde kullan�lan de�i�kenler
	FATFS fatfs;	  // File system object
	WORD  br,bw;
	BYTE buff[4];
///////////////////////////////////////////
	unsigned char bSayac;	// Saya� de�i�keni
	unsigned char bSifre[4]={'1','2','3','4'};	// �ifre "1234"

void main (void)
{
	WDTCTL 	=  WDTPW + WDTHOLD;			// Watchdog timeri durdur
    WDTCTL  = WDTPW | WDTHOLD;			// Watchdog timeri durdur.
    BCSCTL1 = CALBC1_16MHZ;				// Dahili osilat�r� 16MHz'e ayarla.
    DCOCTL = CALDCO_16MHZ;				// Dahili osilat�r� 16MHz'e ayarla.
	P1DIR 	&= ~BIT0;					// Port1.0 giri�
	P1DIR	|= BIT2 + BIT4;				// R�lelerin ba�l� oldu�u pinleri ��k�� yap
	P1SEL	&= ~(BIT0 + BIT2 + BIT4);	// Port1.0,2,4 I/O olarak kullan�lacak
	P1SEL2	&= ~(BIT0 + BIT2 + BIT4);	// Port1.0,2,4 I/O olarak kullan�lacak
	P1REN	|= BIT0;					// Port1.0 Pull-up/down direnci aktif
	P1OUT	|= BIT0;					// Port1.0 Pull-up �zelli�i aktif
	P1OUT	&= ~(BIT2 + BIT4);			// R�leleri ba�lang��ta kapat
	P2DIR	|= BIT1 + BIT2;				// Port2.1-2 ��k��
	P2SEL	&= ~(BIT1 + BIT2);			// Port2.1-2 I/O olarak kullan�lacak
	P2SEL2	&= ~(BIT1 + BIT2);			// Port2.1-2 I/O olarak kullan�lacak
	P2OUT	&= ~(BIT1 + BIT2);			// Port2.1-2 ��k��lar�n� s�f�rla
	spi_initialize();					// USCI_B0 birimini SPI i�in haz�rla

	while(1) {							// Sonsuz d�ng�
	while(P1IN & BIT0);					// Butona(P1.0) bas�lmas�n� bekle
	_delay_cycles(16000);				// Buton ark�n� �nlemek i�in bir s�re bekle
	while(!(P1IN & BIT0));				// Butonun(P1.0) b�rak�lmas�n� bekle
	if(pf_mount(&fatfs)==RES_OK){		// Kart� a�
	if(pf_open("sifre.txt")==RES_OK){	// sifre.txt doyas�n� a�
	if(pf_read(buff,4, &br)==RES_OK){	// Dosyadan 4 karakter �ifreyi oku
	if(bSifre[0]==buff[0])				// �ifrenin 1. hanesini kontrol et
	if(bSifre[1]==buff[1])				// �ifrenin 2. hanesini kontrol et
	if(bSifre[2]==buff[2])				// �ifrenin 3. hanesini kontrol et
	if(bSifre[3]==buff[3])				// �ifrenin 4. hanesini kontrol et
	Dogru();							// �ifre do�ru ise do�ru uyar�s� ver ve r�leleri �ektir.
	else								// Yanl�� ise?
	Yanlis();							// Yanl�� uyar�s� ver
	if(pf_write(0, 0, &bw)!=RES_OK)		// Dosyay� kapat
	Yanlis();					// Dosya kapanmad� ise yanl�� uyar�s� ver.
	} else Yanlis();			// Karakterler okunmad�ysa yanl�� uyar�s� ver
	} else Yanlis();			// Dosya a��lmad�ysa yanl�� uyar�s� ver
	} else Yanlis();			// Kart a��lmad�ysa yada yoksa yanl�� uyar�s� ver
	}							// Sonsuz d�ng� bitimi
}								// Ana program sonu

// Do�ru uyar�s� verip r�leleri �ektiren fonksiyon
void Dogru(void){
	P2OUT |= BIT1;
	P1OUT |= BIT2 + BIT4;		// R�leleri �ektir
	Bekle(1000);				// Bir s�re bekle
	P2OUT &= ~BIT1;
	P1OUT &= ~(BIT2 + BIT4);	// R�leleri b�rak
	Bekle(500);
}

// Port2.2 pinine ba�l� LED ile uyar� veren fonksiyon
void Yanlis(void){
	P2OUT |= BIT2;
	Bekle(500);
	P2OUT &= ~BIT2;
	Bekle(500);
	P2OUT |= BIT2;
	Bekle(500);
	P2OUT &= ~BIT2;
	Bekle(500);
}

// Genel ama�l� bekleme fonksiyonu
void Bekle (unsigned int Bekle){
	unsigned int i;
	for(i=0;i<Bekle;i++)
	_delay_cycles(16000);
}

