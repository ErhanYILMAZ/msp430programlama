/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 9.2									*
 * Tarih: 04-06-2014									*
 * A��klama: DS1302'li saat ve takvim uygulamas�		*
 * **************************************************** */

#include <msp430.h> 				// MSP430 ba�l�k dosyas�
#include "LCD.h"					// LCD ba�l�k dosyas�
#include "DS1302.h"					// DS1302 ba�l�k dosyas�

// Butonlara ait pin tan�mlar�
#define BUTTON_PORT_IN		P1IN
#define BUTTON_PORT_OUT		P1OUT
#define BUTTON_PORT_DIR		P1DIR
#define BUTTON_PORT_SEL		P1SEL
#define BUTTON_PORT_SEL2	P1SEL2
#define BUTTON_PORT_REN		P1REN
#define BUTTON_PORT_IE		P1IE
#define BUTTON_PORT_IES		P1IES
#define BUTTON_PORT_IFG		P1IFG
#define MENU_ARTTIR	BIT0
#define MENU_AZALT	BIT1
#define ARTTIR		BIT2
#define AZALT		BIT3
// LCD ile ilgili makrolar
#define Kursor_Ac	LCD_Komut_Yaz(0x0e)
#define Kursor_Kapa LCD_Komut_Yaz(0x0c)
// Fonksiyon prototipleri
void Gun_Yazd�r(unsigned char);
void Sayi_Yazdir(unsigned char);
void Saat_Tarih_Goster(void);
struct _DS1302 DS1302;					// Saat/tarih bilgilerini tutan yap�
unsigned char bGecikmeSayac=0,bMenu=0;	// Kullan�lan de�i�kenler
void main(void) {
    WDTCTL  = WDTPW | WDTHOLD;		// Watchdog timeri durdur.
    BCSCTL1 = CALBC1_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    DCOCTL = CALDCO_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    DS1302_Ayarla();				// DS1302 ayarlar�
    LCD_Ayarla();					// LCD ayarlar�
    // Buton ayarlar�
    BUTTON_PORT_DIR  &= ~(MENU_ARTTIR + MENU_AZALT + ARTTIR + AZALT);
    BUTTON_PORT_REN  |=  (MENU_ARTTIR + MENU_AZALT + ARTTIR + AZALT);
    BUTTON_PORT_OUT  |=  (MENU_ARTTIR + MENU_AZALT + ARTTIR + AZALT);
    BUTTON_PORT_SEL	 &= ~(MENU_ARTTIR + MENU_AZALT + ARTTIR + AZALT);
    BUTTON_PORT_SEL2 &= ~(MENU_ARTTIR + MENU_AZALT + ARTTIR + AZALT);
    BUTTON_PORT_IE   |=  (MENU_ARTTIR + MENU_AZALT + ARTTIR + AZALT);
    BUTTON_PORT_IE   |=  (MENU_ARTTIR + MENU_AZALT + ARTTIR + AZALT);
    BUTTON_PORT_IFG  &= ~(MENU_ARTTIR + MENU_AZALT + ARTTIR + AZALT);
    /////////////////////////////////////////////////////////////////
    TA0CCTL0 = CCIE;				// Timer0 CCR0 ayarlar�
    TA0CCR0  = 50000;				// Timer0 kesme periyodu ~50ms
    TA0CTL   = TASSEL_2 + MC_2;		// Timer0 ayarlar�
    LCD_Temizle();					// LCD ekran� temizle
    Saat_Tarih_Goster();			// Saat ve tarih bilgisini g�ster
    while(1){						// Sonsuz d�ng�
    _BIS_SR(GIE + LPM0_bits);		// Kesmeleri a� uykuya gir
    // Men� artt�rma butonu kontrol ediliyor
    if(!(BUTTON_PORT_IN & MENU_ARTTIR)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & MENU_ARTTIR));
    if(++bMenu>7) bMenu=0;}
    // Man� azaltma butonu kontrol ediliyor
    if(!(BUTTON_PORT_IN & MENU_AZALT)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & MENU_AZALT));
    if(bMenu>1) bMenu--;}
    // Se�ilen men�ye g�re LCD ekran g�ncellenir
    switch(bMenu){
    // Ay g�n� ayar�n�n yap�ld��� k�s�m
    case 1:
    LCD_Git_XY(1,9);
    Kursor_Ac;
    if(!(BUTTON_PORT_IN & ARTTIR)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & ARTTIR));
    if(++DS1302.AyinGunu>31)DS1302.AyinGunu=1;
    Sayi_Yazdir(DS1302.AyinGunu);}
    if(!(BUTTON_PORT_IN & AZALT)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & AZALT));
    if(--DS1302.AyinGunu==0)DS1302.AyinGunu=31;
    Sayi_Yazdir(DS1302.AyinGunu);}
    LCD_Git_XY(1,9);
    break;
    // Ay ayar�n�n yap�ld��� k�s�m
    case 2:
    LCD_Git_XY(1,12);
    Kursor_Ac;
    if(!(BUTTON_PORT_IN & ARTTIR)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & ARTTIR));
    if(++DS1302.Ay>12)DS1302.Ay=1;
    Sayi_Yazdir(DS1302.Ay);}
    if(!(BUTTON_PORT_IN & AZALT)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & AZALT));
    if(--DS1302.Ay==0)DS1302.Ay=12;
    Sayi_Yazdir(DS1302.Ay);}
    LCD_Git_XY(1,12);
    break;
    // Sene ayar�n�n yap�ld��� k�s�m
    case 3:
    LCD_Git_XY(1,15);
    Kursor_Ac;
    if(!(BUTTON_PORT_IN & ARTTIR)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & ARTTIR));
    if(++DS1302.Sene>99)DS1302.Sene=0;
    Sayi_Yazdir(DS1302.Sene);}
    if(!(BUTTON_PORT_IN & AZALT)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & AZALT));
    if(--DS1302.Sene>99)DS1302.Sene=99;
    Sayi_Yazdir(DS1302.Sene);}
    LCD_Git_XY(1,15);
    break;
    // Haftan�n g�n� ayar�n�n yap�ld��� k�s�m
    case 4:
    LCD_Git_XY(2,1);
    Kursor_Ac;
    if(!(BUTTON_PORT_IN & ARTTIR)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & ARTTIR));
    if(++DS1302.HaftaninGunu>7)DS1302.HaftaninGunu=1;
    Gun_Yazd�r(DS1302.HaftaninGunu);}
    if(!(BUTTON_PORT_IN & AZALT)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & AZALT));
    if(--DS1302.HaftaninGunu==0)DS1302.HaftaninGunu=7;
    Gun_Yazd�r(DS1302.HaftaninGunu);}
    LCD_Git_XY(2,1);
    break;
    // Saat ayar�n�n yap�ld��� k�s�m
    case 5:
    LCD_Git_XY(2,9);
    Kursor_Ac;
    if(!(BUTTON_PORT_IN & ARTTIR)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & ARTTIR));
    if(++DS1302.Saat>23)DS1302.Saat=0;
    Sayi_Yazdir(DS1302.Saat);}
    if(!(BUTTON_PORT_IN & AZALT)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & AZALT));
    if(--DS1302.Saat>23)DS1302.Saat=23;
    Sayi_Yazdir(DS1302.Saat);}
    LCD_Git_XY(2,9);
    break;
    // Dakika ayar�n�n yap�ld��� k�s�m
    case 6:
    LCD_Git_XY(2,12);
    Kursor_Ac;
    if(!(BUTTON_PORT_IN & ARTTIR)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & ARTTIR));
    if(++DS1302.Dakika>59)DS1302.Dakika=0;
    Sayi_Yazdir(DS1302.Dakika);}
    if(!(BUTTON_PORT_IN & AZALT)){
    _delay_cycles(1000);
    while(!(BUTTON_PORT_IN & AZALT));
    if(--DS1302.Dakika>59)DS1302.Dakika=59;
    Sayi_Yazdir(DS1302.Dakika);}
    LCD_Git_XY(2,12);
    break;
    // Ayarlar�n tamamland��� DS1302'nin g�ncellendi�i k�s�m
    case 7:
    DS1302_Saat_Tarih_Yaz(&DS1302);
    Kursor_Kapa;
    LCD_Temizle();
    LCD_Git_XY(1,2);
    LCD_Yazi_Yaz("SAAT ve TARiH");
    LCD_Git_XY(2,4);
    LCD_Yazi_Yaz("AYARLANDI");
    bGecikmeSayac=0;
    _BIS_SR(GIE + LPM0_bits);
    Saat_Tarih_Goster();
    bMenu=0;
    break;
    // Normal �al��mada �al��an k�s�m
    default:
    Kursor_Kapa;
    Saat_Tarih_Goster();
    break;
    }
    }											// Sonsuz d�ng�
}
// Girilen 0-99 aras� say�y� LCD ekranda yazd�ran fonksiyon
void Sayi_Yazdir(unsigned char Sayi){
	if(Sayi<100){
	LCD_Karakter_Yaz(Sayi/10+0x30);
	LCD_Karakter_Yaz(Sayi%10+0x30);
}}
// Saat ve tarih bilgisini DS1302'den okuyup LCD ekrana yazd�ran fonksiyon
void Saat_Tarih_Goster(void){
    DS1302_Saat_Tarih_Oku(&DS1302);	// DS1302'den saat/tarih bilgisini oku
    LCD_Git_XY(1,1);				// Kurs�r� 1.sat�r 1.s�tuna g�t�r
    LCD_Yazi_Yaz("Tarih:  ");		// LCD ekrana Tarih: yazd�r.
    LCD_Karakter_Yaz(DS1302.AyinGunu/10+0x30);	// Ay g�n� onlar basama��n� yazd�r
    LCD_Karakter_Yaz(DS1302.AyinGunu%10+0x30);	// Ay g�n� birler basama��n� yazd�r.
    LCD_Karakter_Yaz('-');						// - yazd�r.
    LCD_Karakter_Yaz(DS1302.Ay/10+0x30);		// Ay�n onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Ay%10+0x30);		// Ay�n birler basama��n� yazd�r.
    LCD_Karakter_Yaz('-');						// - yazd�r.
    LCD_Karakter_Yaz(DS1302.Sene/10+0x30);		// Senenin onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Sene%10+0x30);		// Senenin birler basama��n� yazd�r.
    LCD_Git_XY(2,1);							// Kurs�r� 2.sat�r 1.s�tuna g�t�r.
    Gun_Yazd�r(DS1302.HaftaninGunu);			// Haftan�n g�n�n� yazd�r.
    LCD_Karakter_Yaz(' ');						// Bo�luk karakteri yazd�r.
    LCD_Karakter_Yaz(DS1302.Saat/10+0x30);		// Saatin onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Saat%10+0x30);		// Saatin birler basama��n� yazd�r.
    LCD_Karakter_Yaz('-');						// - yazd�r.
    LCD_Karakter_Yaz(DS1302.Dakika/10+0x30);	// Dakikan�n onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Dakika%10+0x30);	// Dakikan�n birler basama��n� yazd�r.
    LCD_Karakter_Yaz('-');						// - yazd�r.
    LCD_Karakter_Yaz(DS1302.Saniye/10+0x30);	// Saniyenin onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Saniye%10+0x30);	// Saniyenin birler basama��n� yazd�r.
}
// Girilen 1-7 aras� de�ere g�re haftan�n g�nlerini yazd�ran fonksiyon
void Gun_Yazd�r(unsigned char Gun){
	switch(Gun){
	case 1:LCD_Yazi_Yaz("PZRTESi");break;
	case 2:LCD_Yazi_Yaz("SALI   ");break;
	case 3:LCD_Yazi_Yaz("CRSAMBA");break;
	case 4:LCD_Yazi_Yaz("PRSEMBE");break;
	case 5:LCD_Yazi_Yaz("CUMA   ");break;
	case 6:LCD_Yazi_Yaz("CMRTESi");break;
	case 7:LCD_Yazi_Yaz("PAZAR  ");break;
	default:break;
	}
}

// Port 1 kesme vekt�r�, butonlara bas�l�rsa i�lemci uykudan uyand�r�l�r.
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
  BUTTON_PORT_IFG &= ~(MENU_ARTTIR + MENU_AZALT + ARTTIR + AZALT);
  __bic_SR_register(GIE);
  __bic_SR_register_on_exit(CPUOFF);
}

// Timer_A0 Zamanlay�c�s� CCR0 kesme vekt�r�
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
{
	if(++bGecikmeSayac>=20){			// ~1sn oldu mu?
	bGecikmeSayac=0;					// Sayac� s�f�rla
	__bic_SR_register_on_exit(CPUOFF);	// ��lemciyi uykudan uyand�r.
	}
	TA0CCR0 += 50000;					// Zamanlay�c�y� yeniden kur.
}
