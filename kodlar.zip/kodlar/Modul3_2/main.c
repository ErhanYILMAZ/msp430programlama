/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 3.2									*
 * Tarih: 04-06-2014									*
 * A��klama: �zel karakter g�sterimi					*
 * **************************************************** */


#include <msp430.h>				// MSP430 ba�l�k dosyas�
#include "LCD.h"				// LCD ba�l�k dosyas�
void Ozel_Karakterler();		// �zel karakterler fonkisyon prototipi

void main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Watchdog timeri durdur.
    LCD_Ayarla();				// Ba�lang��ta LCD ayarlar�n� yap.
    Ozel_Karakterler();			// �zel karakterleri y�kle.
    LCD_Git_XY(1,1);			// Kurs�r� 1.sat�r 1.s�tuna g�t�r.
    LCD_Yazi_Yaz("T");			// Ekranda T yaz.
    LCD_Karakter_Yaz(5);		// Ekranda � yaz.
    LCD_Yazi_Yaz("RK");			// Ekranda RK yaz.
    LCD_Karakter_Yaz(0);		// Ekranda � yaz.
    LCD_Yazi_Yaz("E KARAKTER"); // Ekranda E KARAKTER yaz.
    LCD_Git_XY(2,5);			// Kurs�r� 2. sat�r 5. s�tuna g�t�r.
    LCD_Karakter_Yaz(0);		// Ekranda � yaz.
    LCD_Karakter_Yaz(1);		// Ekranda � yaz.
    LCD_Karakter_Yaz(2);		// Ekranda � yaz.
    LCD_Karakter_Yaz(3);		// Ekranda � yaz.
    LCD_Karakter_Yaz(4);		// Ekranda � yaz.
    LCD_Karakter_Yaz(5);		// Ekranda � yaz.
    LCD_Karakter_Yaz(6);		// Ekranda � yaz.
    LCD_Karakter_Yaz(7);		// Ekranda santigrat i�eretini yaz.
    LPM4;						// Denetleyiciyi uyku moduna ge�ir.
}

// LCD'ye �zel T�rk�e karakterleri ve santigrat i�aretini tan�tan fonksiyon
void Ozel_Karakterler()
{
// CGRAM 1.Adrese ; '�' Karakteri
   LCD_Komut_Yaz(0x40);
   LCD_Karakter_Yaz(0x0E);LCD_Karakter_Yaz(0x11);LCD_Karakter_Yaz(0x10);LCD_Karakter_Yaz(0x10);
   LCD_Karakter_Yaz(0x11);LCD_Karakter_Yaz(0x0E);LCD_Karakter_Yaz(0x04);LCD_Karakter_Yaz(0x00);
// CGRAM 2.Adrese ; '�' Karakteri
   LCD_Karakter_Yaz(0x0E);LCD_Karakter_Yaz(0x00);LCD_Karakter_Yaz(0x0F);LCD_Karakter_Yaz(0x10);
   LCD_Karakter_Yaz(0x13);LCD_Karakter_Yaz(0x11);LCD_Karakter_Yaz(0x0F);LCD_Karakter_Yaz(0x00);
// CGRAM 3.Adrese ; 'I' Karakteri
   LCD_Karakter_Yaz(0x04);LCD_Karakter_Yaz(0x00);LCD_Karakter_Yaz(0x0E);LCD_Karakter_Yaz(0x04);
   LCD_Karakter_Yaz(0x04);LCD_Karakter_Yaz(0x04);LCD_Karakter_Yaz(0x0E);LCD_Karakter_Yaz(0x00);
// CGRAM 4.Adrese ; '�' Karakteri
   LCD_Karakter_Yaz(0x0A);LCD_Karakter_Yaz(0x00);LCD_Karakter_Yaz(0x0E);LCD_Karakter_Yaz(0x11);
   LCD_Karakter_Yaz(0x11);LCD_Karakter_Yaz(0x11);LCD_Karakter_Yaz(0x0E);LCD_Karakter_Yaz(0x00);
// CGRAM 5.Adrese ; 'S' Karakteri
   LCD_Karakter_Yaz(0x0F);LCD_Karakter_Yaz(0x10);LCD_Karakter_Yaz(0x10);LCD_Karakter_Yaz(0x0E);
   LCD_Karakter_Yaz(0x01);LCD_Karakter_Yaz(0x05);LCD_Karakter_Yaz(0x1E);LCD_Karakter_Yaz(0x00);
// CGRAM 6.Adrese ; '�' Karakteri
   LCD_Karakter_Yaz(0x0A);LCD_Karakter_Yaz(0x00);LCD_Karakter_Yaz(0x11);LCD_Karakter_Yaz(0x11);
   LCD_Karakter_Yaz(0x11);LCD_Karakter_Yaz(0x11);LCD_Karakter_Yaz(0x0E);LCD_Karakter_Yaz(0x00);
// CGRAM 7.Adrese ; 'i' Karakteri
   LCD_Karakter_Yaz(0x00);LCD_Karakter_Yaz(0x00);LCD_Karakter_Yaz(0x0C);LCD_Karakter_Yaz(0x04);
   LCD_Karakter_Yaz(0x04);LCD_Karakter_Yaz(0x04);LCD_Karakter_Yaz(0x0E);LCD_Karakter_Yaz(0x00);
// CGRAM 8.Adrese ; '�' Sembol�
   LCD_Karakter_Yaz(0x0C);LCD_Karakter_Yaz(0x12);LCD_Karakter_Yaz(0x12);LCD_Karakter_Yaz(0x0C);
   LCD_Karakter_Yaz(0x00);LCD_Karakter_Yaz(0x00);LCD_Karakter_Yaz(0x00);LCD_Karakter_Yaz(0x00);
}
