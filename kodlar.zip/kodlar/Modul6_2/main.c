/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 6.2									*
 * Tarih: 04-06-2014									*
 * A��klama: ADC10 DTC moud kullan�m�					*
 * **************************************************** */

#include <msp430.h>		// MSP430 ba�l�k dosyas�
#include "LCD.h"		// LCD ba�l�k dosyas�

void BCDCevir(unsigned short);			// Fonksiyon prototipi.
unsigned char bBCDDeger[4];				// BCD de�erleri tutan dizi
unsigned short wADCHam[2];
void main(void) {
    WDTCTL = WDTPW | WDTHOLD;			// Watchdog timeri durdur.
    LCD_Ayarla();						// Ba�lang��ta LCD ayarlar�n� yap.
    ADC10CTL1 = INCH_1 + CONSEQ_3;      // A1-A0, tekrarl� �oklu kanal
    ADC10CTL0 = ADC10SHT_2 + MSC + ADC10ON + ADC10IE; // Kesme aktif, �oklu �evrim aktif
    ADC10AE0 = BIT0 + BIT1;				// A0,A1 ADC �zelli�ini aktif et
    ADC10DTC1 = 0x02;					// Toplamda her seferinde 2 �evrim yap�lacak
    _BIS_SR(GIE);						// Kesmeleri a�
    while(1){							// Sonsuz d�ng�
    ADC10CTL0 &= ~ENC;					// ADC kapal�
    while (ADC10CTL1 & BUSY);			// ADC10 me�gul iken bekle
    ADC10SA = (unsigned int)&wADCHam;	// �evrim kay�t ba�lang�� adresi
    ADC10CTL0 |= ENC + ADC10SC;			// ADC10'u a� �evrimi ba�lat
    _BIS_SR(LPM0_bits);					// Uykuya gir
    LCD_Git_XY(1,1);					// �mleci 1.sat�r 1.s�tuna g�t�r.
    LCD_Yazi_Yaz("A0 Ham=");			// Ekrana A0 Ham= yazd�r.
    BCDCevir(wADCHam[1]);				// A0 Ham de�erini BCD'ye �evir
    LCD_Karakter_Yaz(bBCDDeger[3]); 	// Binler basama��n� yazd�r.
    LCD_Karakter_Yaz(bBCDDeger[2]);		// Y�zler basama��n� yazd�r.
    LCD_Karakter_Yaz(bBCDDeger[1]);		// Onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(bBCDDeger[0]);		// Birler basama��n� yazd�r.
    LCD_Git_XY(2,1);					// �mleci 2.sat�r 1.s�tuna g�t�r.
    LCD_Yazi_Yaz("A1 Ham=");			// Ekrana A1 Ham= yazd�r.
    BCDCevir(wADCHam[0]);				// A1 Ham de�erini BCD'ye �evir
    LCD_Karakter_Yaz(bBCDDeger[3]); 	// Binler basama��n� yazd�r.
    LCD_Karakter_Yaz(bBCDDeger[2]);		// Y�zler basama��n� yazd�r.
    LCD_Karakter_Yaz(bBCDDeger[1]);		// Onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(bBCDDeger[0]);		// Birler basama��n� yazd�r.
    }
}

// 0-9999 Aras� girilen say�y� BCD'ye �evirip dizide saklayan fonksiyon.
void BCDCevir(unsigned short Sayi){
	unsigned char bSayac;			// Saya� de�i�keni.
	for(bSayac=0;bSayac<4;bSayac++){
	bBCDDeger[bSayac] = Sayi%10 + 0x30;
	Sayi /= 10;
	}
}


// ADC10 kesme vekt�r�
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
  __bic_SR_register_on_exit(CPUOFF);        // ��lemciyi uykudan uyand�r.
}
