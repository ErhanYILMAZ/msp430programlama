/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 1.2									*
 * Tarih: 04-06-2014									*
 * A��klama: Break point ile debug uygulamas�			*
 * **************************************************** */

#include <msp430.h> 

void main(void)
{
  WDTCTL = WDTPW + WDTHOLD;                 // Watchdog timeri durdur
  P1DIR |= BIT0;                            // P1.0 ��k��
  CCTL0 = CCIE;                             // CCR0 kesmesini a�
  CCR0 = 50000;								// Kesme s�resini ayarla
  TACTL = TASSEL_2 + MC_2;                  // Zamanlay�c� ayarlar�
  _BIS_SR(LPM0_bits + GIE);                 // Uyku moduna gir ve kesmelere izin ver
}

// Timer A0 kesme vekt�r�
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
{
  P1OUT ^= BIT0;                            // P1.0'� tersle
  CCR0 += 50000;                            // Zamanlay�c�y� tekrar kur
}
