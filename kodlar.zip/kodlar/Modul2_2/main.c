/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 2.2									*
 * Tarih: 04-06-2014									*
 * A��klama: Buton kullan�m uygulamas�					*
 * **************************************************** */

#include <msp430.h> 

unsigned short wSayac;					// Saya� de�i�keni
void main(void) {
    WDTCTL = WDTPW | WDTHOLD;			// Watchdog timeri durdur.
    P1DIR |=  BIT0;						// Port1.0 ��k��.
    P2DIR &= ~BIT0;						// Port2.0 giri�.
    P2REN |=  BIT0;						// Port2.0 direnci aktif
    P2OUT |=  BIT0;						// Port2.0 giri�i Pull-Up
    while(1){							// Sonsuz d�ng�
    if(!(P2IN & BIT0)){					// Butona bas�ld� m�?
    for(wSayac=0;wSayac<1000;wSayac++)	// Buton ark�n� �nlemek i�in bekle
    while(!(P2IN & BIT0));				// Butonun b�rak�lmas�n� bekle
    P1OUT ^=  BIT0;						// Port1.0 bitini tersle
    		}
    	}
	}
