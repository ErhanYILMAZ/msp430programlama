/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 2.1									*
 * Tarih: 04-06-2014									*
 * A��klama: Temel port okuma yazma uygulamas�			*
 * **************************************************** */

#include <msp430.h> 

void main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Watchdog timeri durdur.
    P1DIR = 0xff;				// Port1 tamam� ��k��.
    P2DIR = 0x00;				// Port2 tamam� giri�.
    P2REN = 0xff;				// Port2 diren�leri aktif et.
    P2OUT = 0x00;				// Port2 Pull-Down.
    P2SEL = 0x00;				// Port2 I/O olarak kullan�lacak.
    P2SEL2= 0x00;				// Port2 I/O olarak kullan�lacak.
    while(1){					// Sonsuz d�ng�ye gir.
    P1OUT = P2IN;				// Port2'yi oku Port1'e yaz.
    }
}
