/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 7.2									*
 * Tarih: 04-06-2014									*
 * A��klama: UART ile bilgisayar �zerinden kontrol		*
 * **************************************************** */

#include <msp430.h>				// MSP430 ba�l�k dosyas�

void main(void)
{
  WDTCTL  = WDTPW | WDTHOLD;	// Watchdog timeri durdur.
  DCOCTL = 0;					// Dahili osilat�r ayarlar�n� en d���k yap
  BCSCTL1 = CALBC1_1MHZ;		// Dahili osilat�r� 1MHz'e ayarla
  DCOCTL = CALDCO_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla
  P1SEL = BIT1;					// P1.1 = RXD
  P1SEL2 = BIT1;				// P1.1 = RXD
  P2DIR  = 0xff;				// Port2 ��k��
  P2OUT  = 0x00;				// Port2 ��k���n� s�f�rla
  P2SEL  = 0x00;				// Port2 port i�lemleri i�in kullan�lacak
  P2SEL2 = 0x00;				// Port2 port i�lemleri i�in kullan�lacak
  UCA0CTL1 |= UCSSEL_2;			// UART Ayarlar�, Saat kayna�� SMCLK
  UCA0BR0 = 104;				// 1MHz 9600 bud ayar�
  UCA0BR1 = 0;					// 1MHz 9600 baud ayar�
  UCA0MCTL = UCBRS0;			// UART Baud hassas ayar
  UCA0CTL1 &= ~UCSWRST;			// USCI birimini haz�rla
  IE2 |= UCA0RXIE;				// USCI_A0 RX kesmesini a�
  __bis_SR_register(LPM0_bits + GIE);	// Genel kesmeleri a� LPM0 moduna gir
}

//  USCIAAB0 RX Kesme vekt�r�
#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void)
{
  unsigned char bAlinanKarakter;	// Gelen veriyi tutan de�i�ken
  bAlinanKarakter = UCA0RXBUF;		// Gelen veriyi al
  switch(bAlinanKarakter){			// Gelen veriyi kontrol et
  case '0':							// 0 ise
    P2OUT = 0x00;					// Port2 ��k���n� s�f�rla
    break;
  case '1':							// 1 ise
  P2OUT ^= BIT0;					// Port2.0'� tersle
  	break;
  case '2':							// 2 ise
    P2OUT ^= BIT1;					// Port2.1'i tersle
    break;
  case '3':							// 3 ise
    P2OUT ^= BIT2;					// Port2.2'yi tersle
    break;
  case '4':							// 4 ise
    P2OUT ^= BIT3;					// port2.3'� tersle
    break;
  case '5':							// 5 ise
    P2OUT ^= BIT4;					// Port2.4'� tersle
    break;
  case '6':							// 6 ise
    P2OUT ^= BIT5;					// Port2.5'i tersle
    break;
  case '7':							// 7 ise
    P2OUT ^= BIT6;					// Port2.6'y� tersle
    break;
  case '8':							// 8 ise
    P2OUT ^= BIT7;					// Port2.7'yi tersle
    break;
  case '9':							// 9 ise
    P2OUT = 0xff;					// Port2 ��k���n� set et
    break;
  }
}
