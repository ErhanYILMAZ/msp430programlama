/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 4.1									*
 * Tarih: 04-06-2014									*
 * A��klama: periyodik zamanlay�c� uygulamas�			*
 * **************************************************** */

#include <msp430.h> 

unsigned char bSayac=0;			// Kesme saya� de�i�keni
void main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Watchdog timeri durdur.
    BCSCTL1 = CALBC1_1MHZ;		// Dahili osilat�r� 1MHz'e ayarla.
    DCOCTL = CALDCO_1MHZ;		// Dahili osilat�r� 1MHz'e ayarla.
    P1DIR |= BIT0;				// Port1.0 ��k��.
    CCTL0 = CCIE;				// CCR0 kesmesini a�
    CCR0 = 50000;				// CCR0 50 ms ayarla.
    TACTL = TASSEL_2 + MC_2;	// Zamanlay�c� ayarlar�.
    _BIS_SR(LPM0_bits + GIE);	// LPM0 moduna gir kesmeleri a�.
}

#pragma vector=TIMER0_A0_VECTOR	// Timer0_A0 kesme vekt�r�
__interrupt void Timer_A (void)
{
  if(++bSayac==10){				// Sayac 10 olmu� mu?
  P1OUT ^= BIT0;				// Port1.0'� tersle.
  bSayac = 0; }					// Sayac� s�f�rla.
  CCR0 += 50000;				// CCR0'� tekrar kur.
}
