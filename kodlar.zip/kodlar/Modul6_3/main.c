/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 6.3									*
 * Tarih: 04-06-2014									*
 * A��klama: ADC10 ile besleme gerilimi �l��m�			*
 * **************************************************** */

#include <msp430.h> 						// MSP430 ba�l�k dosyas�

#define   GOSTERGE1   		BIT0       		// P2.0 G�sterge1 yetki pini
#define   GOSTERGE2	  		BIT1       		// P2.1 G�sterge2 yetki pini
#define   GOSTERGE3   		BIT2       		// P2.2 G�sterge3 yetki pini
#define   GOSTERGE4   		BIT3       		// P2.3 G�sterge4 yetki pini
#define   NOKTA_SEGMENET	BIT7			// Nokta segmenti
#define   SEGMENT_DATA_PORT			P1OUT	// Segment veri portu
#define	  SEGMENT_DATA_PORT_DIR		P1DIR	// Segment veri portu y�nlendirme kaydedicisi
#define	  SEGMENT_DATA_PORT_SEL1	P1SEL	// Segment veri portu se�me1 kaydedicisi
#define	  SEGMENT_DATA_PORT_SEL2	P1SEL2	// Segment veri portu se�me2 kaydedicisi
#define   GOSTERGE_PORT			P2OUT		// G�sterge se�me portu
#define	  GOSTERGE_PORT_DIR		P2DIR		// G�sterge se�mme portu y�nlendirme kaydedicisi
#define	  GOSTERGE_PORT_SEL1	P2SEL		// G�sterge se�me portu se�me1 kaydedicisi
#define	  GOSTERGE_PORT_SEL2	P2SEL2		// G�sterge se�me portu se�me2 kaydedicisi
void BCDCevir(unsigned short);				// Fonksiyon prototipi.
unsigned char bGostergeSayac=1;				// G�sterge saya� de�i�keni
unsigned char bGostergeData[4];				// G�stergelere yazd�ralan de�erleri tutan dizi
unsigned char bNokta=0;						// G�stergelerin nokta bilgisini tutan de�i�ken
unsigned short wAVCC=0;						// AVCC gerilim de�erini tutan de�i�ken
unsigned char bGecikmeSayac=0;				// Gecikme sayac�
// 7 Par�a g�sterge porta yaz�lan karakter de�erleri 0-9, A-F karakterleri ve U harfi
const unsigned char SegmentDataTablo[17]={0X3F,0X06,0X5B,0X4F,0X66,0X6D,0X7D,0X07,0X7F,0X6F,0X77,0X7C,0X39,0X5E,0X79,0X71,0x3E};

void main(void) {
    WDTCTL  = WDTPW | WDTHOLD;		// Watchdog timeri durdur.
    BCSCTL1 = CALBC1_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    DCOCTL = CALDCO_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    SEGMENT_DATA_PORT_DIR  = 0xFF;	// Segment portu ��k��
    SEGMENT_DATA_PORT	   = 0x00;	// Segment portunu ba�lang��ta s�f�rla
    SEGMENT_DATA_PORT_SEL1 = 0x00;	// Segment portu port i�lemlerinde kullan�lacak
    SEGMENT_DATA_PORT_SEL2 = 0x00;	// Segment portu port i�lemlerinde kullan�lacak
    GOSTERGE_PORT_DIR  |=   GOSTERGE1 + GOSTERGE2 + GOSTERGE3 + GOSTERGE4;	// G�sterge pinlerini ��k�� yap
    GOSTERGE_PORT	   &= ~(GOSTERGE1 + GOSTERGE2 + GOSTERGE3 + GOSTERGE4);	// G�stergeler ba�lang��ta pasif
    GOSTERGE_PORT_SEL1 &= ~(GOSTERGE1 + GOSTERGE2 + GOSTERGE3 + GOSTERGE4);	// G�sterge portu port i�lemlerinde kullan�alacak
    GOSTERGE_PORT_SEL2 &= ~(GOSTERGE1 + GOSTERGE2 + GOSTERGE3 + GOSTERGE4); // G�sterge portu port i�lemlerinde kullan�alacak
    TA0CCTL0 = CCIE;					// Timer0 CCR0 ayarlar�
    TA0CCR0  = 5000-1;					// Timer0 kesme periyodu 5ms
    TA0CTL   = TASSEL_2 + MC_2;			// Timer0 ayarlar�
    ADC10CTL1 = INCH_11;                // AVcc/2 dahili kanal�n� se�
    // ADC10 ayarlar�, dahili 2.5V referans, kesmeleri a�
    ADC10CTL0 = SREF_1 + ADC10SHT_2 + REFON + REF2_5V + ADC10ON + ADC10IE;
    bNokta = BIT0;						// G�sterge 1 noktas�n� yak
    bGostergeData[3] = 16;				// G�sterge 4'te U(Volt) de�erini g�ster
    ADC10CTL0 |= ENC + ADC10SC;         // AD �evrimi ba�lat
    _BIS_SR(GIE);						// Kesmeleri a�
    while(1){							// Sonsuz d�ng�
    _BIS_SR(LPM0_bits);					// Uykuya gir
    wAVCC = (ADC10MEM*20)/41;			// Okunan de�eri gerilime �evir
    BCDCevir(wAVCC);					// Gerilim de�erini BCD'ye �evir g�sterge de�i�kenlerine yaz.
}}

// 0-999 Aras� girilen say�y� BCD'ye �eviren fonksiyon
void BCDCevir(unsigned short Sayi){
	unsigned char bSayac;
	for(bSayac=0;bSayac<3;bSayac++){
	bGostergeData[2-bSayac]= Sayi%10;
	Sayi /= 10;
	}
}

// ADC10 kesme vekt�r�
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
  __bic_SR_register_on_exit(CPUOFF);        // ��lemciyi uykudan uyand�r.
}

// S�rayla g�stergeleri aktif eden ve ilgili verileri segment portuna yazan CCR0 kesme rutini
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
{
	switch(bGostergeSayac){		// S�rada hangi g�sterge var?
	case 1:		// G�sterge 1 ise aktif et veriyi segment portuna yaz.
	SEGMENT_DATA_PORT = SegmentDataTablo[bGostergeData[0]] ;
	if(bNokta & BIT0) SEGMENT_DATA_PORT |= NOKTA_SEGMENET;
	GOSTERGE_PORT |= GOSTERGE1;
	GOSTERGE_PORT &= ~(GOSTERGE2 + GOSTERGE3 + GOSTERGE4);
	bGostergeSayac=2;		// 2. g�stergeye ge�
	break;
	case 2:		// G�sterge 2 ise aktif et veriyi segment portuna yaz.
	SEGMENT_DATA_PORT = SegmentDataTablo[bGostergeData[1]] ;
	if(bNokta & BIT1) SEGMENT_DATA_PORT |= NOKTA_SEGMENET;
	GOSTERGE_PORT |= GOSTERGE2;
	GOSTERGE_PORT &= ~(GOSTERGE1 + GOSTERGE3 + GOSTERGE4);
	bGostergeSayac=3;		// 3. g�stergeye ge�
	break;
	case 3:		// G�sterge 3 ise aktif et veriyi segment portuna yaz.
	SEGMENT_DATA_PORT = SegmentDataTablo[bGostergeData[2]] ;
	if(bNokta & BIT2) SEGMENT_DATA_PORT |= NOKTA_SEGMENET;
	GOSTERGE_PORT |= GOSTERGE3;
	GOSTERGE_PORT &= ~(GOSTERGE1 + GOSTERGE2 + GOSTERGE4);
	bGostergeSayac=4;		// 4. g�stergeye ge�
	break;
	case 4:		// G�sterge 4 ise aktif et veriyi segment portuna yaz.
	SEGMENT_DATA_PORT = SegmentDataTablo[bGostergeData[3]] ;
	if(bNokta & BIT3) SEGMENT_DATA_PORT |= NOKTA_SEGMENET;
	GOSTERGE_PORT |= GOSTERGE4;
	GOSTERGE_PORT &= ~(GOSTERGE1 + GOSTERGE2 + GOSTERGE3);
	bGostergeSayac=1;		// 1. g�stergeye ge�
	break;
	}
	if(++bGecikmeSayac>=100){			// 500 ms oldu mu?
	bGecikmeSayac=0;					// Zaman sayac�n� s�f�rla
	ADC10CTL0 |= ENC + ADC10SC;         // AD �evrimi ba�lat
	}
	TA0CCR0 += 5000;					// Timeri yeniden kur.
}
