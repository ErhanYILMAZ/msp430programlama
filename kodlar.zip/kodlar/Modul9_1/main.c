/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 9.1									*
 * Tarih: 04-06-2014									*
 * A��klama: DS1302 kullan�m�							*
 * **************************************************** */

#include <msp430.h> 				// MSP430 ba�l�k dosyas�
#include "LCD.h"					// LCD ba�l�k dosyas�
#include "DS1302.h"					// DS1302 ba�l�k dosyas�

struct _DS1302 DS1302;				// Saat/tarih bilgilerini tutan yap�
unsigned char bGecikmeSayac=0;		// Gecikme sayac�
void main(void) {
    WDTCTL  = WDTPW | WDTHOLD;		// Watchdog timeri durdur.
    BCSCTL1 = CALBC1_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    DCOCTL = CALDCO_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    DS1302_Ayarla();				// DS1302 ayarlar�
    LCD_Ayarla();					// LCD ayarlar�
    TA0CCTL0 = CCIE;				// Timer0 CCR0 ayarlar�
    TA0CCR0  = 50000;				// Timer0 kesme periyodu ~50ms
    TA0CTL   = TASSEL_2 + MC_2;		// Timer0 ayarlar�
    DS1302.Saniye=0;				// Saniyeyi ayarla
    DS1302.Dakika=40;				// Dakikay� ayarla
    DS1302.Saat=19;					// Saati ayarla
    DS1302.AyinGunu=18;				// Ay�n g�n�n� ayarla
    DS1302.Ay=5;					// Ay� ayarla
    DS1302.HaftaninGunu=7;			// Haftan�n g�n�n� ayarla
    DS1302.Sene=14;					// Seneyi ayarla
    DS1302_Saat_Tarih_Yaz(&DS1302);	// Ayarlanan de�erleri DS1302'ye yaz
    LCD_Temizle();					// LCD ekran� temizle
    _BIS_SR(GIE);					// Kesmeleri a�
    while(1){						// Sonsuz d�ng�
    DS1302_Saat_Tarih_Oku(&DS1302);	// DS1302'den saat/tarih bilgisini oku
    LCD_Git_XY(1,1);				// Kurs�r� 1.sat�r 1.s�tuna g�t�r
    LCD_Yazi_Yaz("Tarih:");			// LCD ekrana Tarih: yazd�r.
    LCD_Karakter_Yaz(DS1302.AyinGunu/10+0x30);	// Ay g�n� onlar basama��n� yazd�r
    LCD_Karakter_Yaz(DS1302.AyinGunu%10+0x30);	// Ay g�n� birler basama��n� yazd�r.
    LCD_Karakter_Yaz('-');						// - yazd�r.
    LCD_Karakter_Yaz(DS1302.Ay/10+0x30);		// Ay�n onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Ay%10+0x30);		// Ay�n birler basama��n� yazd�r.
    LCD_Karakter_Yaz('-');						// - yazd�r.
    LCD_Karakter_Yaz(DS1302.Sene/10+0x30);		// Senenin onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Sene%10+0x30);		// Senenin birler basama��n� yazd�r.
    LCD_Git_XY(2,1);							// Kurs�r� 2.sat�r 1.s�tuna g�t�r.
    LCD_Yazi_Yaz("Saat :");						// LCD ekrana Saat : yazd�r.
    LCD_Karakter_Yaz(DS1302.Saat/10+0x30);		// Saatin onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Saat%10+0x30);		// Saatin birler basama��n� yazd�r.
    LCD_Karakter_Yaz('-');						// - yazd�r.
    LCD_Karakter_Yaz(DS1302.Dakika/10+0x30);	// Dakikan�n onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Dakika%10+0x30);	// Dakikan�n birler basama��n� yazd�r.
    LCD_Karakter_Yaz('-');						// - yazd�r.
    LCD_Karakter_Yaz(DS1302.Saniye/10+0x30);	// Saniyenin onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(DS1302.Saniye%10+0x30);	// Saniyenin birler basama��n� yazd�r.
    _BIS_SR(LPM0_bits);							// Uykuya gir
    }											// Sonsuz d�ng�
}

// Timer_A0 Zamanlay�c�s� CCR0 kesme vekt�r�
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
{
	if(++bGecikmeSayac>=20){			// ~1sn oldu mu?
	bGecikmeSayac=0;					// Sayac� s�f�rla
	__bic_SR_register_on_exit(CPUOFF);	// ��lemciyi uykudan uyand�r.
	}
	TA0CCR0 += 50000;					// Zamanlay�c�y� yeniden kur.
}
