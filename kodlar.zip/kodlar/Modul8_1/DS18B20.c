/*
 Erhan YILMAZ
 04-05-2014
 MSP430 denetleyiciler i�in DS18B20 s�cakl�k sens�r� k�t�phanesidir.
 MSP430G2553 denetleyicisinde 1MHz dahili osilat�r ile test edilmi�tir.
 Farkl� frekans de�erleri i�in ayarlamalar�n yap�lmas� gerekmektedir.
 */
#include "msp430.h"
#include "DS18B20.h"
#include "onewire.h"
char yazi[9];
void DS18B20_Ayarla(){
	TekHatAyarla();
}

// DS18B20'de ham olarak s�cakl�k verisini okuyan fonksiyon
unsigned int DS18B20_Oku(){
	unsigned char high_byte,low_byte;
	while(TekHatReset());
	TekHatByteYaz(SKIPROM_CMD);
	TekHatByteYaz(CONVERT_TMP);
	while(TekHatReset());
	TekHatByteYaz(SKIPROM_CMD);
	TekHatByteYaz(READ_SCRATCHPAD);
	__delay_cycles(120);
	low_byte  = TekHatByteOku();
	high_byte = TekHatByteOku();
	return (high_byte<<8 & 0xff00) + low_byte;
}

// DS18B20_Oku fonkisyonu ile okunan de�eri i�aret,
// ondal�k ve tam say� k�s�mlar�na ay�r�p asciiye �eviren fonksiyon
char* DS18B20_Yaziya_Cevir(unsigned int sayi){
	unsigned char gecici;
	if(sayi & 0xF000)
	yazi[0] = '-';
	else
	yazi[0] = '+';
	gecici = sayi>>4 & 0xff;
	yazi[1] = gecici/100 + 0x30;
	gecici %= 100;
	yazi[2] = gecici/10 + 0x30;
	yazi[3] = gecici%10 + 0x30;
	yazi[4] = '.';
	gecici = sayi & 0x000f;
	sayi = gecici * 625;
	yazi[5] = sayi/1000 + 0x30;
	sayi = sayi % 1000;
	yazi[6] = sayi/100 + 0x30;
	sayi = sayi % 100;
	yazi[7] = sayi / 10 + 0x30;
	yazi[8] = sayi % 10 + 0x30;
	return yazi;
}

