/*
 Erhan YILMAZ
 04-05-2014
 MSP430 denetleyiciler i�in DS18B20 s�cakl�k sens�r� k�t�phanesidir.
 MSP430G2553 denetleyicisinde 1MHz dahili osilat�r ile test edilmi�tir.
 Farkl� frekans de�erleri i�in ayarlamalar�n yap�lmas� gerekmektedir.
 */

#ifndef __DS18B20_H
#define __DS18B20_H

// Fonksiyon prototipleri
void DS18B20_Ayarla();
unsigned int DS18B20_Oku();
char* DS18B20_Yaziya_Cevir(unsigned int);

#endif
