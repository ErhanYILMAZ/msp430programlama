/*
 Erhan YILMAZ	04-05-2014
 erhanyilmaz.ytu@gmail.com
 MSP430 tek hat(one wire) ileti�im k�t�phanesi.
 MSP430G2553 denetleyicisinde 1MHz dahili osilat�r ile test edilmi�tir.
 Zamanlama ayarlar� 1MHz i�indir. Farkl� frekanslarda kullanmak i�in
 gerekli zamanlamalar�n yap�lmas� gerekir.
*/

#include "msp430.h"
#include "onewire.h"

// One wire ileti�im i�in hatt� haz�rlar.
void TekHatAyarla (){
	OW_DIR_LOW;
	OW_OUT_HIGH;
}

// One wire ileti�im i�in hatta reset i�areti g�nderir.
unsigned char TekHatReset(){
	OW_OUT_LOW;
	OW_DIR_HIGH;
	__delay_cycles(500);	// 500us
	OW_DIR_LOW;
	__delay_cycles(100);	// 100us
	if(OW_INPUT_READ){
	__delay_cycles(400);	// 400us
	return 1;}
	else{
	__delay_cycles(400);	// 400us
	return 0;}
	
}

// One wire ileti�im i�in hatta 1 bit veri yazar.
void TekHatBitYaz (unsigned char bit){
	__delay_cycles(2);		// 2us
	OW_DIR_HIGH;
	OW_OUT_LOW;
	if(bit)
	__delay_cycles(4);		// 4us
	else
	__delay_cycles(64);		// 64us
	OW_DIR_LOW;
	if(bit)
	__delay_cycles(64);		// 64us
	else
	__delay_cycles(4);		// 4us
}

// One wire ileti�im i�in hattan 1 bit veri okur.
unsigned char TekHatBitOku (){
	unsigned char bit;
	__delay_cycles(2);		// 2us
	OW_OUT_LOW;
	OW_DIR_HIGH;
	__delay_cycles(2);		// 2us
	OW_DIR_LOW;
	__delay_cycles(15);		// 15us
	bit=OW_INPUT_READ;
	__delay_cycles(60);		// 60us
	return bit;
}

// One wire ileti�imde hatta bir byte veri yazar.
void TekHatByteYaz(unsigned char veri){
	unsigned char sayac;
	for(sayac = 0; sayac < 8; sayac++)
	{
    TekHatBitYaz(veri & 0x01);
    veri >>= 1;
	}
}

// One wire ileti�imde hattan bir byte veri okur.
unsigned char TekHatByteOku(){
	unsigned char sayac;
	unsigned char veri;
    for(sayac = 0; sayac < 8; sayac++)
    {
    veri >>= 1;
    if (TekHatBitOku()) veri |= 0x80;
	else
	veri &= 0x7F;
    }
    return veri;
}
