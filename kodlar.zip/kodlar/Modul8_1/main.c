/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 8.1									*
 * Tarih: 04-06-2014									*
 * A��klama: DS18B20 kullan�m�							*
 * **************************************************** */

#include <msp430.h> 			// MSP430 ba�l�k dosyas�
#include "DS18B20.h"			// DS18B20 ba�l�k dosyas�
#include "LCD.h"				// LCD ba�l�k dosyas�

unsigned int wISIHam;			// Ham s�cakl�k de�erini tutan de�i�ken
void main(void) {				// Ana fonksiyon ba�lang�c�
	WDTCTL  = WDTPW | WDTHOLD;	// Watchdog timeri durdur.
	BCSCTL1 = CALBC1_1MHZ;		// Dahili osilat�r� 1MHz'e ayarla
	DCOCTL = CALDCO_1MHZ;		// Dahili osilat�r� 1MHz'e ayarla
	DS18B20_Ayarla();			// DS18B20 ayarla
	LCD_Ayarla();				// LCD ayarla
	while(1){					// Sonsuz d�ng�
	wISIHam=DS18B20_Oku();		// DS18B20'den s�cakl��� oku
	LCD_Git_XY(1,1);			// LCD kurs�r� 1. sat�r 1. s�tuna g�t�r.
	LCD_Yazi_Yaz("DS18B20 DENEMESi");	// Ekrana DS18B20 DENEMESi yazd�r.
	LCD_Git_XY(2,1);			// LCD kurs�r� 2. sat�r 1. s�tuna g�t�r.
	LCD_Yazi_Yaz("ISI= ");		// Ekrana ISI yazd�r.
	LCD_Yazi_Yaz(DS18B20_Yaziya_Cevir(wISIHam));	// S�cakl�k de�erini ay�r�p ekrana yazd�r
	LCD_Karakter_Yaz(0xDF);		// Santigrat i�aretini yazd�r
	LCD_Karakter_Yaz('C');		// C karakterini yazd�r.
	}
}


