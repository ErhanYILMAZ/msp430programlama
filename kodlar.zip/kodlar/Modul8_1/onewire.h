/*
 Erhan YILMAZ	04-05-2014
 erhanyilmaz.ytu@gmail.com
 MSP430 tek hat(one wire) ileti�im k�t�phanesi.
 MSP430G2553 denetleyicisinde 1MHz dahili osilat�r ile test edilmi�tir.
 Zamanlama ayarlar� 1MHz i�indir. Farkl� frekanslarda kullanmak i�in
 gerekli zamanlamalar�n yap�lmas� gerekir.
*/

#ifndef __ONEWIRE_H
#define __ONEWIRE_H

#define CONVERT_TMP     0x44	// S�cakl�k �l��m komutu
#define SKIPROM_CMD     0xCC	// Rom atlama komutu
#define READ_SCRATCHPAD 0xBE	// Scratchpad okuma komutu
#define OW_PORT_OUT		P2OUT	// One wire bit	portu
#define OW_PORT_DIR		P2DIR	// One wire biti y�nlendirme kaydedicisi
#define OW_PORT_IN		P2IN	// One wire biti port okuma kaydedicisi
#define OW_PORT_BIT		BIT4	// One wire ileti�im port biti
#define OW_OUT_HIGH		(OW_PORT_OUT |=  OW_PORT_BIT)
#define OW_OUT_LOW		(OW_PORT_OUT &= ~OW_PORT_BIT)
#define OW_DIR_HIGH		(OW_PORT_DIR |=  OW_PORT_BIT)
#define OW_DIR_LOW		(OW_PORT_DIR &= ~OW_PORT_BIT)
#define OW_INPUT_READ	(OW_PORT_IN & OW_PORT_BIT)

// Fonksiyon prototipleri
void TekHatAyarla ();
unsigned char TekHatReset();
void TekHatBitYaz (unsigned char bit);
unsigned char TekHatBitOku ();
void TekHatByteYaz(unsigned char byte);
unsigned char TekHatByteOku();

#endif
