/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 4.3									*
 * Tarih: 03:06:2014									*
 * A��klama: PWM �retim uygulamas�						*
 * **************************************************** */

#include <msp430.h> 				// MSP430 ba�l�k dosyas�

unsigned short wPWM=1000;			// PWM de�i�keni, ba�lang�� de�eri 1000
unsigned char bYon=0;				// Y�n de�erini tutan de�i�ken.
void main(void) {
    WDTCTL  = WDTPW | WDTHOLD;		// Watchdog timeri durdur.
    BCSCTL1 = CALBC1_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    DCOCTL = CALDCO_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    P2DIR |= BIT2 + BIT4;			// P2.2, P2.4 ��k��.
    P2SEL |= BIT2 + BIT4;			// P2.2, P2.4 timer i�in kullan�lacak.
    TA1CCR0 = 1000;					// Timer1 PWM periyodu 1000+1 cycle yakla��k 1kHz
    TA1CCTL1 = OUTMOD_7;			// Timer1 CCR1 PWM ayarlar�
    TA1CCTL2 = OUTMOD_7;			// Timer1 CCR2 PWM ayarlar�
    TA1CCR1  = 0;					// Timer1 CCR1 ba�lang�� de�eri
    TA1CCR2  = 0;					// Timer1 CCR2 ba�lang�� de�eri
    TA1CTL   = TASSEL_2 + MC_1;		// Timer1 ayarlar�
    TA0CCTL0 = CCIE;				// Timer0 CCR0 ayalar�
    TA0CCR0  = 20000;				// Timer0 kesme periyodu ~20ms
    TA0CTL   = TASSEL_2 + MC_2;		// Timer0 ayarlar�
    _BIS_SR(LPM0_bits + GIE);		// Kesmeleri a� uykuya gir.
}

// Timer0 CCR0 kesme vekt�r�
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
{
  if(bYon)					// Y�n yukar� m�?
  {
	  wPWM += 10;			// PWM de�erini artt�r
	  if(wPWM>1000)			// PWM 1000 den b�y�k m�?
	  {
		  wPWM=1000;		// Evet ise PWM de�erini 1000 yap
		  bYon=0;			// Y�n� de�i�tir.(A�a��)
	  }
  } else					// Y�n a�a�� m�?
  {
	wPWM -= 10;				// PWM de�erini azalt.
	if(wPWM == 0)			// PWM 0 oldu mu?
	{
		wPWM=0;				// Evet ise PWM de�erini 0 yap.
		bYon=1;				// Y�n� de�i�tir. (Yukar�)
	}
  }
  TA1CCR1 =  wPWM;			// TA1CCR1'e PWM de�erini y�kle.
  TA1CCR2 =  1000- wPWM;	// TA1CCR2'ye PWM de�erinin tersini y�kle.
  TA0CCR0 += 20000;     	// TA0CCR0'� tekrar kur.
}
