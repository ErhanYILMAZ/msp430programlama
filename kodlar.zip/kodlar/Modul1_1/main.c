/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 1.1									*
 * Tarih: 04-06-2014									*
 * A��klama: Ad�m ad�m debug uygulamas�					*
 * **************************************************** */

#include <msp430.h> 

void main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Watchdog timeri durdur
	P1DIR = 0xFF;				// Port 1 t�m bitler ��k��
	P1OUT = 0xFF;				// Port 1'e ba�l� t�m ledleri yak
	P1OUT = 0x00;				// Port 1'e ba�l� t�m ledleri s�nd�r
	P1OUT |=  BIT0;				// LED 1 yak
	P1OUT |=  BIT1;				// LED 2 yak
	P1OUT |=  BIT2;				// LED 3 yak
	P1OUT |=  BIT3;				// LED 4 yak
	P1OUT &= ~BIT3;				// LED 4 s�nd�r
	P1OUT &= ~BIT2;				// LED 3 s�nd�r
	P1OUT &= ~BIT1;				// LED 2 s�nd�r
	P1OUT &= ~BIT0;				// LED 1 s�nd�r
}

