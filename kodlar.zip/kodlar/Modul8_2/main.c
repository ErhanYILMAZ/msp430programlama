/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 8.2									*
 * Tarih: 04-06-2014									*
 * A��klama: DS18B20 ile dahili s�cakl�k				*
 * sens�r�n�n kar��lat�r�lmas�							*
 * **************************************************** */

#include <msp430.h> 			// MSP430 ba�l�k dosyas�
#include "DS18B20.h"			// DS18B20 ba�l�k dosyas�
#include "LCD.h"				// LCD ba�l�k dosyas�

void BCDCevir(unsigned short);	// BCDCevir fonksiyon prototipi

unsigned char bBCDSayi[4];				// BCD de�erleri tutan dizi
unsigned char bGecikmeSayac=0;			// Gecikme sayac�
unsigned int wISIHam;					// Ham s�cakl�k de�erini tutan de�i�ken
unsigned long	wSicaklik;				// S�cakl�k de�erini tutan de�i�ken
void main(void) {						// Ana fonksiyon ba�lang�c�
	WDTCTL  = WDTPW | WDTHOLD;			// Watchdog timeri durdur.
	BCSCTL1 = CALBC1_1MHZ;				// Dahili osilat�r� 1MHz'e ayarla
	DCOCTL = CALDCO_1MHZ;				// Dahili osilat�r� 1MHz'e ayarla
	DS18B20_Ayarla();					// DS18B20 ayarla
	LCD_Ayarla();						// LCD ayarla
    TA0CCTL0 = CCIE;					// Timer0 CCR0 ayarlar�
    TA0CCR0  = 5000-1;					// Timer0 kesme periyodu 5ms
    TA0CTL   = TASSEL_2 + MC_2;			// Timer0 ayarlar�
    ADC10CTL1 = INCH_10 + ADC10DIV_3;   // S�cakl�k sens�r� se�ilir. ADC10CLK/4
    // ADC10 ayarlar�, dahili 1.5V referans, kesmeleri a�
    ADC10CTL0 = SREF_1 + ADC10SHT_3 + REFON + ADC10ON + ADC10IE;
    _BIS_SR(GIE);						// Kesmeleri a�
	while(1){							// Sonsuz d�ng�
	_BIS_SR(LPM0_bits);					// Uykuya gir
	wSicaklik = ADC10MEM;				// �evrim sonucunu kaydet
	wSicaklik = ((wSicaklik - 673) * 42300) / 1024;	// �evrim sonucunu santigrat dereceye �evir
	BCDCevir(wSicaklik);				// S�cakl�k de�erini rakamlar�na ay�r.
	LCD_Git_XY(1,1);					// LCD kurs�r� 1.sat�r 1.s�t�na g�t�r.
	LCD_Yazi_Yaz("Dahili=");			// Ekrana "Dahili=" yazd�r.
	LCD_Karakter_Yaz(bBCDSayi[0]+0x30);	// Onlar basama��n� yazd�r
	LCD_Karakter_Yaz(bBCDSayi[1]+0x30);	// Birler basama��n� yazd�r.
	LCD_Karakter_Yaz('.');				// Noktayazd�r
	LCD_Karakter_Yaz(bBCDSayi[2]+0x30);	// Onda birler basama��n� yazd�r.
	LCD_Karakter_Yaz(bBCDSayi[3]+0x30);	// Y�zde birler basama��n� yazd�r.
	LCD_Karakter_Yaz(0xDF);				// Santigrat i�aretini yazd�r
	LCD_Yazi_Yaz("C  ");				// "C  " yaz�s�n� yazd�r.
	wISIHam=DS18B20_Oku();				// DS18B20'den s�cakl��� oku
	LCD_Git_XY(2,1);					// LCD kurs�r� 2. sat�r 1. s�tuna g�t�r.
	LCD_Yazi_Yaz("Harici=");			// Ekrana "Harici=" yazd�r.
	LCD_Yazi_Yaz(DS18B20_Yaziya_Cevir(wISIHam)+2);	// S�cakl�k de�erini ay�r�p ekrana yazd�r
	LCD_Karakter_Yaz(0xDF);				// Santigrat i�aretini yazd�r
	LCD_Karakter_Yaz('C');				// C karakterini yazd�r.
	}
}

// Timer0_A0 kesme vekt�r�
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
{	if(++bGecikmeSayac>=100){			// 500 ms oldu mu?
	bGecikmeSayac=0;					// Zaman sayac�n� s�f�rla
	ADC10CTL0 |= ENC + ADC10SC;         // AD �evrimi ba�lat
	}
	TA0CCR0 += 5000;					// Timeri yeniden kur.
}

// ADC10 kesme vekt�r�
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
  __bic_SR_register_on_exit(CPUOFF);	// ��lemciyi uykudan uyand�r.
}

// 0-9999 Aras� girilen say�y� BCD'ye �eviren fonksiyon
void BCDCevir(unsigned short Sayi){
	unsigned char bSayac;
	for(bSayac=0;bSayac<4;bSayac++){
		bBCDSayi[3-bSayac]= Sayi%10;
	Sayi /= 10;
	}
}
