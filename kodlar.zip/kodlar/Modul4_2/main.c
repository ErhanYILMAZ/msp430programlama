/********************************************************
 * Yazar: Erhan YILMAZ									*
 * �sim:  Uygulama 4.2									*
 * Tarih: 04-06-2014									*
 * A��klama: Yakalama (Capture) uygulamas�				*
 * **************************************************** */

#include <msp430.h> 				// MSP430 ba�l�k dosyas�.
#include "LCD.h"					// LCD ba�l�k dosyas�

void BCDCevir(unsigned short);		// Fonksiyon prototipi
unsigned char bBCDDeger[4];			// BCD de�erleri tutan dizi
unsigned short wDeger;				// Yakalanan de�eri tutan de�i�ken
void main(void) {
    WDTCTL  = WDTPW | WDTHOLD;		// Watchdog timeri durdur.
    BCSCTL1 = CALBC1_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    DCOCTL = CALDCO_1MHZ;			// Dahili osilat�r� 1MHz'e ayarla.
    LCD_Ayarla();					// LCD ba�lang�� ayarlar�.
    P1DIR  &= ~BIT2;				// P1.2 Giri�.
    P1REN  |=  BIT2;				// P1.2 Diren� aktif.
    P1OUT  |=  BIT2;				// P1.2 pull-Up.
    P1SEL  |=  BIT2;				// P1.2 Timer i�in kullan�lacak.
    P1SEL2 &= ~BIT2;				// P1.2 Timer i�in kullan�lacak.
    TA0CCR0  = 9999;				// Timer 0-9999 aras�nda sayacak.
    TA0CTL = TASSEL_2 + MC_1;		// Up mode, SMCLK se�ildi.
    TA0CCTL1 = CM_2 + CAP + CCIE;	// D��en kenar yakalama, kesme aktif.
    _BIS_SR(GIE);					// Kesmeleri a�
    while(1){						// Sonsuz d�ng�
    _BIS_SR(LPM0_bits);				// Uykuya gir
    LCD_Git_XY(1,1);				// �mleci 1.sat�r 1.s�tuna g�t�r.
    LCD_Yazi_Yaz("Capture Denemesi");	// Ekrana Capture Denemesi yazd�r.
    LCD_Git_XY(2,4);				// �mleci 2.sat�r 4.s�tuna g�t�r.
    LCD_Yazi_Yaz("Deger=");			// Ekrana Deger= yazd�r.
    BCDCevir(wDeger);				// Say�y� BCD'ye �evir
    LCD_Karakter_Yaz(bBCDDeger[3]); // Binler basama��n� yazd�r.
    LCD_Karakter_Yaz(bBCDDeger[2]);	// Y�zler basama��n� yazd�r.
    LCD_Karakter_Yaz(bBCDDeger[1]);	// Onlar basama��n� yazd�r.
    LCD_Karakter_Yaz(bBCDDeger[0]);	// Birler basama��n� yazd�r.
}}

// 0-9999 Aras� girilen say�y� BCD'ye �evirip dizide saklayan fonksiyon.
void BCDCevir(unsigned short Sayi){
	unsigned char bSayac;			// Saya� de�i�keni.
	for(bSayac=0;bSayac<4;bSayac++){
	bBCDDeger[bSayac] = Sayi%10 + 0x30;
	Sayi /= 10;
	}
}

// Timer_A3 Kesme vekt�r� (TA0IV Kesme Kaydedicisi)
#pragma vector=TIMER0_A1_VECTOR
__interrupt void Timer_A(void)
{
  switch( TA0IV ){
  case  2:                                  // CCR1 kesmesi
  wDeger = TA0CCR1;							// Yakalanan de�eri al.
  __bic_SR_register_on_exit(CPUOFF);		// ��lemciyi uykudan uyand�r.
  break;
  case  4: break;                           // CCR2 kesmesi
  case 10: break;                           // Ta�ma kesmesi
 }
}

